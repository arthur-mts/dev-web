package com.ifpb.dev.web.atividade7.banco;

public enum Ordernar {
    ID,
}
