package com.ifpb.dev.web.atividade7.entidades;

public enum Tipo {
    DESTILADO,
    FERMENTADO
}
